import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ajaxdropdown {
	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","E:\\Educational\\selenium\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://busindia.com/");
		driver.findElement(By.id("matchFromPlace")).sendKeys("Thane");
		Thread.sleep(2000);

	    List<WebElement> OptionList = driver.findElements(By.xpath("//ul[contains(@class,'ui-autocomplete')]/li/a"));
	    System.out.println("Found the city : "+OptionList);
	    if(OptionList.size()>=1){
	        for(int i=0;i<OptionList.size();i++)
	        {
	            String CurrentOption = OptionList.get(i).getText();
	            if(CurrentOption.equalsIgnoreCase("thane")){
	                System.out.println("Found the city : "+CurrentOption);
	                OptionList.get(i).click();
	            }
	        }
	    }
	    else{
	        System.out.println("OptionList is empty");
	    }
	}
}
