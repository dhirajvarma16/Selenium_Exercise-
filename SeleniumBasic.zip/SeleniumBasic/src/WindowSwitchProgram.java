import org.openqa.selenium.By;
import org.openqa.selenium.By.ByCssSelector;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class WindowSwitchProgram {

	public static void main(String[] args) {
	   
		System.setProperty("webdriver.chrome.driver", "F:\\stuff\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com");
		
		Actions a = new Actions(driver);
		WebElement elementLocator = driver.findElement(By.xpath("//*[@id='content']/ul/li[21]/a"));
		a.contextClick(elementLocator).sendKeys(Keys.ENTER).sendKeys(Keys.ENTER).build().perform();
		//a.moveToElement(driver.findElement(By.xpath("//*[@id='content']/ul/li[21]/a"))).contextClick()..build().perform();
		
	}

}
