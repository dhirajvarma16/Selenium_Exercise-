
public class SyncTimetest {

	public static void main(String[] args) {
              
		System.setProperty("webdriver.chrome", arg1)

		
		
		
		
			}

}
