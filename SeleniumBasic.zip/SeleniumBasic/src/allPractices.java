import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class allPractices {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","E:\\Educational\\selenium\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://qaclickacademy.com/practice.php");
		driver.findElement(By.xpath("//input[@value='radio1']")).click();
        System.out.println(driver.findElements(By.xpath("//input[@name='radioButton']")).size());
        int count=driver.findElements(By.xpath("//input[@name='radioButton']")).size(); 
        
        for(int i=0;i<count;i++) {
        	driver.findElements(By.xpath("//input[@name='radioButton']")).get(i).click();
        	driver.findElements(By.xpath("//input[@name='radioButton']")).get(i).getAttribute("value");
            
        }
        
       
		
	}

}
