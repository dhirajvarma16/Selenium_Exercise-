import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Miscelleanous {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver","E:\\Educational\\selenium\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://fantasycricket.dream11.com/in/");
		public void  switchtoFrame(WebDriver driver) 
		{
		    int framecount=driver.findElements(By.tagName("iframe")).size();
		  for(int i=0;i<framecount;i++)
		  {
			  driver.switchTo().frame(i);
			  int count = driver.findElements(By.xpath("//"))
		  }
		}
		

	}

}
