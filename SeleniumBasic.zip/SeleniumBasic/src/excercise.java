import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class excercise {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "E:\\Educational\\selenium\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://accounts.google.com/SignUp?hl=en-GB");
		driver.findElement(By.cssSelector("#wrapper > div.signuponepage.main.content.clearfix > div > div.sign-up > p > a")).click();
		System.out.println("Before switching");
		System.out.println(driver.getTitle());
		Set<String> ids=driver.getWindowHandles();
		System.out.println(ids);
		Iterator<String> it=ids.iterator();
		System.out.println(it);
		String parentid = it.next();
		String childid = it.next();
		driver.switchTo().window(parentid);
		
		
		
	}

}
