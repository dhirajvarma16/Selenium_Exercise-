import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Webvalidation1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "E:\\Educational\\selenium\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.makemytrip.com/");
		System.out.print("before cliking on multi radio button");
		System.out.println(driver.findElement(By.xpath("//input[@id='hp-widget__return']")).isDisplayed());
		driver.findElement(By.xpath(".//*[@id='multicity']/label")).click();
		System.out.println(driver.findElement(By.xpath("//input[@id='hp-widget__return']")).isDisplayed());
		System.out.println(driver.findElement(By.xpath("//*[@id='fd-wrap']/div[2]/h2")).getText());

	}

}
