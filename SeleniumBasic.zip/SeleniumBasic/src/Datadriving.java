

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Datadriving {
	
	public void Login() throws IOException
	{
		Properties prop=new Properties();
		System.setProperty("webdriver.chrome.driver", "E:\\Educational\\selenium\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		FileInputStream fis=new FileInputStream("C:\\Users\\Dhiraj varma\\eclipse-workspace\\SeleniumBasic\\src\\datadriven.properties");
		prop.load(fis);
		System.out.println(prop.getProperty("username"));
		System.setProperty("webdriver.chrome.driver", "E:\\Educational\\selenium\\Chromedriver.exe");
		
		if(prop.getProperty("browser").contains("chrome"))
		{
			
		}
	}

}
