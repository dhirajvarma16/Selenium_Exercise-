import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Exerc {
	
   public static void main(String[] args) {
	   System.setProperty("webdriver.chrome.driver", "E:\\Educational\\selenium\\Chromedriver.exe");
	   WebDriver driver= new ChromeDriver();
	   driver.get("https://www.ebay.in/?aff_source=Google_cpc&site=Brand_New_RLSA_Exact");
	   System.out.println(driver.findElements(By.tagName("a")).size());
	   
	   WebElement footer=driver.findElement(By.cssSelector("#glbfooter"));
	   System.out.println(footer.findElements(By.tagName("a")).size());
	   
	   WebElement col= driver.findElement(By.cssSelector("#gf-BIG > table > tbody > tr > td:nth-child(4) > ul"));
	   System.out.println(col.findElements(By.tagName("a")).size());
	   String Beforeclick=null;
	   String Afterclick;
	   
	   for(int i=0; i<=col.findElements(By.tagName("a")).size(); i++) 
	   {
		 System.out.println(col.findElements(By.tagName("a")).get(i).getText());
		 
		 if (col.findElements(By.tagName("a")).get(i).getText().contains("Site Map")) 
		 {
			 Beforeclick= driver.getTitle();
			 col.findElements(By.tagName("a")).get(i).click();
			 break;
			 
		 }}
		 Afterclick = driver.getTitle();
		 if(Beforeclick!=Afterclick)
		 {
		    if(driver.getPageSource().contains("Site Map")) {
		    	System.out.println("PASS");
		    }	 
		    else
			{
				System.out.println("FAIL");
			}
		    	
		 }
		    
	 
 }}
