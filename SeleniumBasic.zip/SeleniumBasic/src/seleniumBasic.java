import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class seleniumBasic {

	public static void main(String[] args) {
	
		System.setProperty("webdriver.chrome.driver","F:\\st0uff\\Chromedriver.exe");
	    WebDriver  driver=new ChromeDriver();
	    driver.get("https://www.facebook.com");
	    driver.findElement(By.cssSelector("#email")).sendKeys("varmad211@gmail.com");
	    driver.findElement(By.xpath("//*[@id='pass']")).sendKeys("Pallu595");
	    driver.findElement(By.linkText("Forgotten account?")).click();
		
		
	}

}
