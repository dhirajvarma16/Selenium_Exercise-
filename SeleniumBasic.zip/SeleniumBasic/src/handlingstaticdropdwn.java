import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByCssSelector;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class handlingstaticdropdwn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.setProperty("webdriver.chrome.driver", "E:\\Educational\\selenium\\Chromedriver.exe");
        WebDriver driver =new ChromeDriver();
        driver.get("http:www.spicejet.com");
        Select s = new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Adult")));
        s.selectByValue("2");
        driver.findElement(By.cssSelector("#ctl00_mainContent_ddl_originStation1_CTXT")).click();
        driver.findElement(By.xpath("//a[@value='DEL']")).click();
        driver.findElement(By.cssSelector("#ctl00_mainContent_ddl_destinationStation1_CTXT")).click();
        driver.findElement(By.xpath("(//a[@value='GOI'])[2]")).click();
        driver.findElement(By.cssSelector("#ctl00_mainContent_view_date1")).click();        
        String month1= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/div/div/span[1]")).getText();
        String month2= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[2]/div/div/span[1]")).getText();
       
       int i=0;
       while(i<12) {
    	   if(month1 =="March" ) {   
    		   System.out.println("This is a month1"+ month1);
//    	   month1= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/div/div/span[1]")).getText();
    	   driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/table/tbody/tr[3]/td[4]")).click();
    	   
    	    }
       else if(month2 =="March"){
    	   System.out.println("This is a month2"+ month2);
//    	   month2= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[2]/div/div/span[1]")).getText();
    	   driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[2]/table/tbody/tr[3]/td[4]")).click();
    	   //
       }
       driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[2]/div/a/span")).click();
       i++;
       }
       
       
       
       System.out.println((month1 +" "+"year months"+month2+"!") );
       
        
        
//        driver.findElement(By.cssSelector("#ui-datepicker-div > div.ui-datepicker-group.ui-datepicker-group-last > div > a > span")).click();
//        String str=driver.findElement(By.cssSelector("#ui-datepicker-div > div.ui-datepicker-group.ui-datepicker-group-last > div > div > span.ui-datepicker-month")).getText();
//        System.out.println(str);
//        driver.findElement(By.cssSelector("#ui-datepicker-div > div.ui-datepicker-group.ui-datepicker-group-first > table > tbody > tr:nth-child(3) > td:nth-child(5) > a")).click();
   	   
    	    
    
}}
