import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Captcha {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","F:\\stuff\\Chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://spinbot.com/Login");
		int i;
		int framecount =driver.findElements(By.tagName("iframe")).size();
		System.out.println(framecount);
		for (i=0;i<framecount;i++)
		{
		driver.switchTo().frame(i);
		int itemcount = driver.findElements(By.className("recaptcha-checkbox-checkmark")).size();
		if(itemcount>0)
		{
		break;
		} else
		{
		System.out.println("Continue");
		}
		driver.switchTo().defaultContent();
		}
		driver.switchTo().defaultContent();
		driver.switchTo().frame(i);
		driver.findElement(By.className("recaptcha-checkbox-checkmark")).click();
		}
	}


