import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
 
public class RightClick {
 
 
    @Test
    public static void main(String[] arg) throws InterruptedException {
 
    	System.setProperty("webdriver.chrome.driver", "F:\\stuff\\Chromedriver.exe")  ;  	
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("http://automate-apps.com/");
        System.out.println(driver.getTitle());
        Actions action = new Actions(driver);
        Thread.sleep(1000);
        WebElement element = driver.findElement(By.xpath("//*[@id='menu-item-1284']/a"));
        String clickonlinkTab=Keys.chord(Keys.CONTROL,Keys.ENTER);
        element.findElement(By.xpath("//*[@id='menu-item-1284']/a")).sendKeys(clickonlinkTab);
        
        //action.moveToElement(element);
        /*action.contextClick(element).build().perform();
        action.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
        Set<String> winid = driver.getWindowHandles();
        Iterator<String> iter = winid.iterator();
        iter.next();
        String tab = iter.next();
        driver.switchTo().window(tab);
        System.out.println(driver.getTitle());
        driver.quit();*/
    }
 
}