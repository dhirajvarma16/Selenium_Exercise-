import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
public class synchroniz {

	public static void main(String[] args) throws InterruptedException 
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "F:\\stuff\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("https://alaskatrips.poweredbygps.com/g/pt/hotels?MDPCID=ALASKA-US.TPS.BRAND.hotels.HOTEL");
		WebElement Origin=driver.findElement(By.id("FH-origin"));
		Origin.sendKeys("nyc");
		Thread.sleep(2000);
		Origin.sendKeys(Keys.ARROW_DOWN);
		Origin.sendKeys(Keys.ENTER);
		WebElement Destination=driver.findElement(By.id("FH-destination"));
		Destination.sendKeys("Los a");
		Thread.sleep(2000);
		Destination.sendKeys(Keys.ARROW_DOWN);
		Destination.sendKeys(Keys.ENTER);
		
				
		driver.findElement(By.xpath("//input[@id='FH-fromDate']")).click();	
		driver.findElement(By.xpath("//*[@id='FH-fromDate-label']/div/div/div[2]/table/tbody/tr[3]/td[5]")).click();
		
		driver.findElement(By.xpath("//*[@id='FH-toDate']")).click();	
		driver.findElement(By.xpath("//*[@id='FH-toDate-label']/div/div/div[2]/table/tbody/tr[4]/td[5]")).click();
		
		Select s=new Select(driver.findElement(By.id("NumRoom")));
		       s.selectByValue("1");
		       
		driver.findElement(By.xpath("//*[@id='FH-searchButtonExt1']")).click(); 
		
		
		WebDriverWait d=new WebDriverWait(driver,20);
		d.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='1683637']/div[2]/div/a")));
		
		driver.findElement(By.xpath("//*[@id='1683637']/div[2]/div/a")).click();
		
		}

}
