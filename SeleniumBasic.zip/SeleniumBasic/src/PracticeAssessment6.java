import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PracticeAssessment6 {
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "F:\\stuff\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://qaclickacademy.com/practice.php");
		 
		driver.findElement(By.xpath("//div[@id='checkbox-example']//fieldset//label[3]//input")).click();
		String opt =driver.findElement(By.xpath("//div[@id='checkbox-example']//fieldset//label[3]")).getText();
		System.out.println(opt);
	    
        Select s=new Select(driver.findElement(By.id("dropdown-class-example")));
        s.selectByVisibleText(opt);
        
        driver.findElement(By.cssSelector("fieldset[class='alert_example']>legend>input[1]")).sendKeys(opt);
	
	}

}
