import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class spiceJet {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","E:\\Educational\\selenium\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.spicejet.com/");
		driver.findElement(By.xpath("//input[@id='ctl00_mainContent_ddl_originStation1_CTXT']")).click();
		
		List<WebElement> dd_list= driver.findElements(By.xpath("//*[@id='dropdownGroup1']/div/ul[1]/li"));
		//for(int i=0;)
		
		//int i=dd_list.size();
		//System.out.println(i);
		
		
	
		
		
	}
	

}
