import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SpiceJetselenium {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "F:\\stuff\\Chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http:\\www.spicejet.com");
		driver.findElement(By.xpath("//input[@id='ctl00_mainContent_rbtnl_Trip_0']")).click();
		driver.findElement(By.xpath("//input[@id='ctl00_mainContent_ddl_originStation1_CTXT']")).clear();
		driver.findElement(By.xpath("//a[@value='IXM']")).click();
		driver.findElement(By.xpath("//input[@id='ctl00_mainContent_ddl_destinationStation1_CTXT']")).click();
		driver.findElement(By.xpath("(//a[@value='GOI'])[2]")).click();
		String month1= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/div/div/span[1]")).getText();
        String month2= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[2]/div/div/span[1]")).getText();
        int i=0;
        while(i<12) {
        	month2= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[2]/div/div/span[1]")).getText();
            System.out.println(month2);
     	   if(month2.equals("June")) {   
     		  driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/table/tbody/tr[3]/td[4]")).click();
     	   break;
     	    }        
        driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[2]/div/a/span")).click();
        i++;
        }
        Thread.sleep(5000);
        
        int k= driver.findElements(By.xpath("//input[@type='checkbox']")).size();
        System.out.println("Size k:"+k);
        
        for(int g=1;g<k;g++) {
        	String[] checkboxText=new String[k];
        	//checkboxText[g]=driver.findElements(By.xpath("//input[@type='checkbox']//label")).get(g).getText();
        	//System.out.println(checkboxText[g]);
        	System.out.println(driver.findElements(By.xpath("//input[@type='checkbox']//label")).get(g).getText());
        	
        	/*if(checkboxText[g].equals("Senior Citizen")) {
        		System.out.println(checkboxText[g]);
        		driver.findElement(By.xpath("//input[@type='checkbox']")).click();
        		break;
        	}*/
        //	checkboxText=null;
        }
	}

}
